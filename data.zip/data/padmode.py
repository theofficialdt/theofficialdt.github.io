import pygame
import os
import sys
import subprocess
import shutil

pygame.init()
pygame.joystick.init()

YANIX_PATH = os.path.expanduser("~/.local/share/yanix-launcher")
CONFIG_PATH = os.path.join(YANIX_PATH, "data/game_path.txt")
LANG_PATH = os.path.join(YANIX_PATH, "data/multilang.txt")
WINEPREFIX_PATH = os.path.join(YANIX_PATH, "data/wineprefix_path.txt")
BACKGROUND_PATH = os.path.join(YANIX_PATH, "data/padmode.png")
YAN_SIM_INSTALL_PATH = os.path.join(YANIX_PATH, "game")
YAN_SIM_NATIVE_EXE_PATH = os.path.join(YAN_SIM_INSTALL_PATH, "YandereSimulator.exe")

LANGUAGES = {
    "en": {"play": "Play", "settings": "Settings", "exit": "Exit Pad Mode", "language": "Language", "select_theme": "Select Theme", "theme_not_available": "Not Available on Pad Mode", "title": "Yanix Launcher Pad Mode", "game_not_found": "Game not found. Please download it first.", "apply": "Apply", "settings_applied": "Settings Applied!"},
    "es": {"play": "Jugar", "settings": "Configuración", "exit": "Salir del Pad Mode", "language": "Idioma", "select_theme": "Seleccionar Tema", "theme_not_available": "No Disponible en Pad Mode", "title": "Yanix Launcher Pad Mode", "game_not_found": "Juego no encontrado. Por favor, descárgalo primero.", "apply": "Aplicar", "settings_applied": "¡Configuración Aplicada!"},
    "pt": {"play": "Jogar", "settings": "Configurações", "exit": "Sair do Pad Mode", "language": "Idioma", "select_theme": "Selecionar Tema", "theme_not_available": "Não Disponível no Pad Mode", "title": "Yanix Launcher Pad Mode", "game_not_found": "Jogo não encontrado. Por favor, baixe-o primeiro.", "apply": "Aplicar", "settings_applied": "Configurações Aplicadas!"},
    "ru": {"play": "Играть", "settings": "Настройки", "exit": "Выйти из Pad Mode", "language": "Язык", "select_theme": "Выбрать тему", "theme_not_available": "Недоступно в Pad Mode", "title": "Yanix Launcher Pad Mode", "game_not_found": "Игра не найдена. Пожалуйста, сначала скачайте ее.", "apply": "Применить", "settings_applied": "Настройки применены!"},
    "ja": {"play": "プレイ", "settings": "設定", "exit": "Pad Modeを終了", "language": "言語", "select_theme": "テーマを選択", "theme_not_available": "Pad Modeでは利用できません", "title": "Yanix Launcher Pad Mode", "game_not_found": "ゲームが見つかりません。まずダウンロードしてください。", "apply": "適用", "settings_applied": "設定が適用されました！"},
    "ko": {"play": "플레이", "settings": "설정", "exit": "Pad Mode 종료", "language": "언어", "select_theme": "테마 선택", "theme_not_available": "Pad Mode에서는 사용할 수 없습니다", "title": "Yanix Launcher Pad Mode", "game_not_found": "게임을 찾을 수 없습니다. 먼저 다운로드하십시오.", "apply": "적용", "settings_applied": "설정이 적용되었습니다!"},
    "ndk": {"play": "Niko", "settings": "Meow", "exit": "Exit Niko Pad", "language": "Niko Languaga", "select_theme": "Niko Theme", "theme_not_available": "Not Available on Niko Pad, stupid", "title": "Niko Launcher Niko Mode", "game_not_found": "Niko game not found, stupid. Download it first.", "apply": "Apply Niko", "settings_applied": "Niko Settings Applied, stupid!"}
}

info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
pygame.display.set_caption("Yanix Launcher Pad Mode")
pygame.mouse.set_visible(False)

try:
    BACKGROUND_IMG = pygame.image.load(BACKGROUND_PATH).convert()
    BACKGROUND_IMG = pygame.transform.scale(BACKGROUND_IMG, (WIDTH, HEIGHT))
except pygame.error:
    BACKGROUND_IMG = None

FONT_TITLE = pygame.font.Font(None, 80)
FONT_MENU = pygame.font.Font(None, 64)
FONT_SETTINGS = pygame.font.Font(None, 50)
FONT_MESSAGE = pygame.font.Font(None, 55)

COLOR_WHITE = (255, 255, 255)
COLOR_PURPLE = (170, 120, 255)
COLOR_GREY = (150, 150, 150)
COLOR_BLACK = (0, 0, 0)
COLOR_BG = (10, 0, 20)

def get_language():
    try:
        if os.path.exists(LANG_PATH):
            with open(LANG_PATH, "r") as f:
                return f.read().strip()
    except IOError:
        return "en"
    return "en"

def save_language(lang_code):
    try:
        with open(LANG_PATH, "w") as f:
            f.write(lang_code)
    except IOError:
        pass

def get_wineprefix_path():
    if os.path.exists(WINEPREFIX_PATH):
        with open(WINEPREFIX_PATH, "r") as f:
            return f.read().strip()
    return None

def get_game_path():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r") as f:
            path = f.read().strip()
            if os.path.exists(path):
                return path
    if os.path.exists(YAN_SIM_NATIVE_EXE_PATH):
        return YAN_SIM_NATIVE_EXE_PATH
    return None

def launch_game(game_exe_path):
    if not game_exe_path or not shutil.which("wine"):
        return
    pygame.display.iconify()
    env = os.environ.copy()
    wineprefix = get_wineprefix_path()
    if wineprefix:
        env["WINEPREFIX"] = wineprefix
    game_dir = os.path.dirname(game_exe_path)
    try:
        process = subprocess.Popen(["wine", game_exe_path], cwd=game_dir, env=env)
        process.wait()
    except Exception as e:
        print(f"Failed to launch game: {e}")
    finally:
        global screen
        screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
        pygame.mouse.set_visible(False)

class PadModeApp:
    def __init__(self):
        self.running = True
        self.clock = pygame.time.Clock()
        self.joystick = None
        if pygame.joystick.get_count() > 0:
            self.joystick = pygame.joystick.Joystick(0)
            self.joystick.init()
        
        self.current_screen = "main"
        self.lang_code = get_language()
        self.lang_data = LANGUAGES.get(self.lang_code, LANGUAGES["en"])
        
        self.main_menu_options = ["play", "settings", "exit"]
        self.settings_menu_options = ["language", "select_theme", "apply"]
        
        self.selected_main = 0
        self.selected_settings = 0
        
        self.language_keys = list(LANGUAGES.keys())
        self.current_lang_index = self.language_keys.index(self.lang_code)
        self.temp_lang_index = self.current_lang_index

        self.input_cooldown = 200 
        self.last_input_time = 0

        self.selected_main_anim_x = 0
        self.selected_settings_anim_x = 0
        self.transition_alpha = 255
        self.transition_state = "fading_in"
        self.next_screen = None

        self.show_apply_message = False
        self.apply_message_timer = 0

    def apply_language_change(self):
        self.current_lang_index = self.temp_lang_index
        self.lang_code = self.language_keys[self.current_lang_index]
        save_language(self.lang_code)
        self.lang_data = LANGUAGES.get(self.lang_code, LANGUAGES["en"])
        self.show_apply_message = True
        self.apply_message_timer = pygame.time.get_ticks()

    def draw_text(self, text, font, color, x, y, center=False, shadow_color=COLOR_BLACK):
        shadow_surface = font.render(text, True, shadow_color)
        text_surface = font.render(text, True, color)
        shadow_rect = shadow_surface.get_rect()
        text_rect = text_surface.get_rect()
        if center:
            shadow_rect.center = (x + 3, y + 3)
            text_rect.center = (x, y)
        else:
            shadow_rect.topleft = (x + 3, y + 3)
            text_rect.topleft = (x, y)
        screen.blit(shadow_surface, shadow_rect)
        screen.blit(text_surface, text_rect)
        
    def draw_panel(self, x, y, width, height, alpha):
        panel_surface = pygame.Surface((width, height), pygame.SRCALPHA)
        panel_surface.fill((0, 0, 0, alpha))
        screen.blit(panel_surface, (x, y))

    def draw_main_menu(self):
        y_offset = HEIGHT // 2 - 50
        self.draw_panel(40, y_offset - 20, 400, 260, 150)
        self.draw_text(self.lang_data["title"], FONT_TITLE, COLOR_WHITE, 50, 50)
        for i, option in enumerate(self.main_menu_options):
            x_pos = 80
            color = COLOR_WHITE
            if i == self.selected_main:
                color = COLOR_PURPLE
                x_pos += self.selected_main_anim_x
            self.draw_text(self.lang_data[option], FONT_MENU, color, x_pos, y_offset + i * 80)
            
    def draw_settings_menu(self):
        self.draw_text(self.lang_data["title"], FONT_TITLE, COLOR_WHITE, 50, 50)

        settings_text = self.lang_data["settings"]
        settings_surf = FONT_MENU.render(settings_text, True, COLOR_WHITE)
        settings_rect = settings_surf.get_rect(topright=(WIDTH - 50, 60))
        self.draw_text(settings_text, FONT_MENU, COLOR_WHITE, settings_rect.left, settings_rect.top)
        
        y_offset = HEIGHT // 2 - 120
        self.draw_panel(40, y_offset - 20, 600, 260, 150)
        
        temp_display_lang_code = self.language_keys[self.temp_lang_index]

        for i, option in enumerate(self.settings_menu_options):
            color = COLOR_PURPLE if i == self.selected_settings else COLOR_WHITE
            x_pos = 80 + (self.selected_settings_anim_x if i == self.selected_settings else 0)
            
            if option == "language":
                self.draw_text(self.lang_data[option], FONT_SETTINGS, color, x_pos, y_offset + i * 80)
                self.draw_text(temp_display_lang_code.upper(), FONT_SETTINGS, color, 400, y_offset + i * 80)
            elif option == "select_theme":
                self.draw_text(self.lang_data[option], FONT_SETTINGS, color, x_pos, y_offset + i * 80)
                self.draw_text(self.lang_data["theme_not_available"], FONT_SETTINGS, COLOR_GREY, 400, y_offset + i * 80)
            elif option == "apply":
                 self.draw_text(self.lang_data[option], FONT_SETTINGS, color, x_pos, y_offset + i * 80)

    def start_transition(self, next_screen):
        if self.transition_state == "none":
            if next_screen == "settings":
                self.temp_lang_index = self.current_lang_index
            self.next_screen = next_screen
            self.transition_state = "fading_out"

    def handle_input(self):
        current_time = pygame.time.get_ticks()
        if self.transition_state != 'none' or self.show_apply_message:
            if self.show_apply_message and current_time - self.apply_message_timer > 2000:
                self.show_apply_message = False
            return
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            is_cooldown = current_time - self.last_input_time < self.input_cooldown

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.current_screen == "settings": self.start_transition("main")
                    else: self.running = False
                
                if self.current_screen == "main":
                    if event.key == pygame.K_DOWN: self.selected_main = (self.selected_main + 1) % len(self.main_menu_options)
                    if event.key == pygame.K_UP: self.selected_main = (self.selected_main - 1) % len(self.main_menu_options)
                    if event.key == pygame.K_RETURN: self.handle_selection()
                elif self.current_screen == "settings":
                    if event.key == pygame.K_DOWN: self.selected_settings = (self.selected_settings + 1) % len(self.settings_menu_options)
                    if event.key == pygame.K_UP: self.selected_settings = (self.selected_settings - 1) % len(self.settings_menu_options)
                    if event.key == pygame.K_LEFT and self.selected_settings == 0: self.temp_lang_index = (self.temp_lang_index - 1) % len(self.language_keys)
                    if event.key == pygame.K_RIGHT and self.selected_settings == 0: self.temp_lang_index = (self.temp_lang_index + 1) % len(self.language_keys)
                    if event.key == pygame.K_RETURN: self.handle_selection()

            if not self.joystick or is_cooldown:
                continue

            if event.type == pygame.JOYHATMOTION:
                hat_x, hat_y = event.value
                if hat_y == -1: self.handle_joy_down()
                if hat_y == 1: self.handle_joy_up()
                if hat_x == -1: self.handle_joy_left()
                if hat_x == 1: self.handle_joy_right()

            if event.type == pygame.JOYAXISMOTION:
                if event.axis == 1:
                    if event.value > 0.8: self.handle_joy_down()
                    if event.value < -0.8: self.handle_joy_up()
                if event.axis == 0:
                     if event.value > 0.8: self.handle_joy_right()
                     if event.value < -0.8: self.handle_joy_left()
            
            if event.type == pygame.JOYBUTTONDOWN:
                if event.button == 0: self.handle_selection()
                if event.button == 1:
                    if self.current_screen == "settings": self.start_transition("main")

    def handle_joy_up(self):
        if self.current_screen == "main": self.selected_main = (self.selected_main - 1) % len(self.main_menu_options)
        elif self.current_screen == "settings": self.selected_settings = (self.selected_settings - 1) % len(self.settings_menu_options)
        self.last_input_time = pygame.time.get_ticks()

    def handle_joy_down(self):
        if self.current_screen == "main": self.selected_main = (self.selected_main + 1) % len(self.main_menu_options)
        elif self.current_screen == "settings": self.selected_settings = (self.selected_settings + 1) % len(self.settings_menu_options)
        self.last_input_time = pygame.time.get_ticks()
        
    def handle_joy_left(self):
        if self.current_screen == "settings" and self.selected_settings == 0:
            self.temp_lang_index = (self.temp_lang_index - 1) % len(self.language_keys)
            self.last_input_time = pygame.time.get_ticks()

    def handle_joy_right(self):
        if self.current_screen == "settings" and self.selected_settings == 0:
            self.temp_lang_index = (self.temp_lang_index + 1) % len(self.language_keys)
            self.last_input_time = pygame.time.get_ticks()

    def handle_selection(self):
        if self.current_screen == "main":
            option = self.main_menu_options[self.selected_main]
            if option == "play":
                game_path = get_game_path()
                if game_path: launch_game(game_path)
            elif option == "settings": self.start_transition("settings")
            elif option == "exit": self.running = False
        elif self.current_screen == "settings":
            option = self.settings_menu_options[self.selected_settings]
            if option == "apply":
                self.apply_language_change()
        
    def update_animations(self):
        target_x = 25
        self.selected_main_anim_x += (target_x - self.selected_main_anim_x) * 0.1
        self.selected_settings_anim_x += (target_x - self.selected_settings_anim_x) * 0.1

        if self.transition_state == "fading_out":
            self.transition_alpha += 20
            if self.transition_alpha >= 255:
                self.transition_alpha = 255
                self.current_screen = self.next_screen
                self.transition_state = "fading_in"
        elif self.transition_state == "fading_in":
            self.transition_alpha -= 20
            if self.transition_alpha <= 0:
                self.transition_alpha = 0
                self.transition_state = "none"

    def run(self):
        while self.running:
            self.handle_input()
            self.update_animations()
            
            if BACKGROUND_IMG:
                screen.blit(BACKGROUND_IMG, (0, 0))
            else:
                screen.fill(COLOR_BG)
            
            if self.current_screen == "main":
                self.draw_main_menu()
            elif self.current_screen == "settings":
                self.draw_settings_menu()

            if self.show_apply_message:
                self.draw_panel(0, 0, WIDTH, HEIGHT, 100)
                self.draw_text(self.lang_data["settings_applied"], FONT_MESSAGE, COLOR_WHITE, WIDTH // 2, HEIGHT // 2, center=True)

            if self.transition_state != "none":
                fade_surface = pygame.Surface((WIDTH, HEIGHT))
                fade_surface.fill(COLOR_BLACK)
                fade_surface.set_alpha(self.transition_alpha)
                screen.blit(fade_surface, (0, 0))
            
            pygame.display.flip()
            self.clock.tick(60)

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    app = PadModeApp()
    app.run()
